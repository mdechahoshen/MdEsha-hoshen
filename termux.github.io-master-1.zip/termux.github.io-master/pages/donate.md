---
layout: page
title: Donate
permalink: /donate
---

Want to support and encourage Termux development with a donation?

### Donate using Patreon

- <https://patreon.com/termux>

### Donate using PayPal

- <https://paypal.me/fornwall>

### Donate using Bitcoin

- [1BXS5qPhJzhr5iK5nmNDSmoLDfB6VmN5hv](bitcoin:1BXS5qPhJzhr5iK5nmNDSmoLDfB6VmN5hv)

![Bitcoin QR code](files/bitcoin.png)

### Donate to termux maintainers

- <https://github.com/termux/termux-packages/wiki/Donate>
