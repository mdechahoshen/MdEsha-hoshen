---
layout: redirect
sitemap: false
permalink: /issues
redirect_to: https://github.com/termux/termux-packages/issues
---
